# play-java-streaming-example

This is an example Play template that demonstrates Streaming with Server Sent Events or Comet, using Akka Streams.

Please see the documentation at:

* <https://www.playframework.com/documentation/latest/JavaComet>
