# Play Java gRPC Example

This example is described in the [Play Java gRPC Example site](https://developer.lightbend.com/guides/play-java-grpc-example/).

This is an example application that shows how to use Akka gRPC to both expose and use gRPC services inside an Play application.

For detailed documentation refer to https://www.playframework.com/documentation/latest/Home and https://developer.lightbend.com/docs/akka-grpc/current/ .


## Sample license

Written in 2018 by Lightbend, Inc.

To the extent possible under law, the author(s) have dedicated all copyright and related
and neighboring rights to this template to the public domain worldwide.
This template is distributed without any warranty. See <http://creativecommons.org/publicdomain/zero/1.0/>.
