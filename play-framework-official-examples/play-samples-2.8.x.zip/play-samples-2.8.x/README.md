# Play samples

[![Build Status](https://travis-ci.com/playframework/play-samples.svg?branch=2.8.x)](https://travis-ci.com/playframework/play-samples)
[![GitHub issues](https://img.shields.io/github/issues/playframework/play-samples.svg?style=flat)](https://github.com/playframework/play-samples/issues)
[![GitHub forks](https://img.shields.io/github/forks/playframework/play-samples.svg?style=flat)](https://github.com/playframework/play-samples/network)
[![GitHub stars](https://img.shields.io/github/stars/playframework/play-samples.svg?style=flat)](https://github.com/playframework/play-samples/stargazers)

#### License

<sup>
To the extent possible under law, the author(s) have dedicated all copyright and
related and neighboring rights to this software to the public domain worldwide.
This software is distributed without any warranty.
</sup>

<br>

<sub>
Unless you explicitly state otherwise, any contribution intentionally submitted
for inclusion by you shall be licensed as above, without any additional terms
or conditions.
</sub>
