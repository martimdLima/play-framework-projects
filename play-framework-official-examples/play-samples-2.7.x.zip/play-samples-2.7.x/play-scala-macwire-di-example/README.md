# play-scala-macwire-di-example

This is an example project for setting up Play with Macwire compile time dependency injection.

For further details, please see:

* <https://www.playframework.com/documentation/latest/ScalaCompileTimeDependencyInjection>
* <https://github.com/adamw/macwire/blob/master/README.md>
* <https://di-in-scala.github.io/>
