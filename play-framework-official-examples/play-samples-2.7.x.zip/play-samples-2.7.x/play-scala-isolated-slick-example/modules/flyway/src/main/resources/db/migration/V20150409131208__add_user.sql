INSERT INTO "users" VALUES (
  'd074bce8-a8ca-49ec-9225-a50ffe83dc2f',
  'myuser@example.com',
  (TIMESTAMP '2013-03-26T17:50:06Z'),
  (TIMESTAMP '2013-03-26T17:50:06Z')
);
